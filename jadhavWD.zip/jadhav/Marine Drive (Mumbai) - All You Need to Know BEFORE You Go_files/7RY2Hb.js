(this.$WP=this.$WP||[]).push(["7RY2Hb",(t,s)=>{"use strict";var u=()=>null;return[()=>{t("default",u)},[]]},[]]);
